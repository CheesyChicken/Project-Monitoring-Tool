const API_BASE_URL =
  process.env.VUE_APP_API_BASE_URL || "http://103.97.164.116:10027";

module.exports = { API_BASE_URL };
