module.exports = {
  secret: "bezkoder-secret-key",
  frontendUri: process.env.FRONTEND,
  email: process.env.EMAIL,
  password: process.env.PASSWORD,
};
