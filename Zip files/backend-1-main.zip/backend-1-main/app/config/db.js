var mysql = require('mysql');

var connection = mysql.createConnection({
  //socketPath: '34.93.103.215/sound-micron-290407:asia-south1:newdatabase',
  /* socketPath     : '/cloudsql/sound-micron-290407:asia-south1:newdatabase', */
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'project_monitoring_prod'
});
 
module.exports=connection;  