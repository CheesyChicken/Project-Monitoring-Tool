module.exports = {
  apps: [
    {
      name: "pims-api",
      script: "./server.js",
      watch: true,
      env: {
        NODE_ENV: "production",
        EMAIL: "viitpuneprojectmonitoring@gmail.com",
        PASSWORD: "viit@123",
        FRONTEND: "http://103.97.164.116:10026",
      },
    },
  ],
};
